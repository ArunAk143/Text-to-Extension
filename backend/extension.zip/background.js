chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      const boxCount = 10;
      for (let i = 0; i < boxCount; i++) {
        const div = document.createElement('div');
        const size = Math.floor(Math.random() * 100) + 50; // 50-150px
        div.style.width = size + 'px';
        div.style.height = size + 'px';
        div.style.backgroundColor = '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
        div.style.position = 'fixed';
        div.style.left = Math.random() * (window.innerWidth - size) + 'px';
        div.style.top = Math.random() * (window.innerHeight - size) + 'px';
        div.style.zIndex = 100000;
        div.style.boxShadow = '0 0 10px rgba(0,0,0,0.5)';
        document.body.appendChild(div);
      }
    }
  });
});